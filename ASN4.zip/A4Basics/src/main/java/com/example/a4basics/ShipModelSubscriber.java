package com.example.a4basics;

public interface ShipModelSubscriber {
    void modelChanged();

    void resetSlider();
}
